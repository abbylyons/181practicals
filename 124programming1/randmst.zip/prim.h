//prim.h

#include "pqueue.h"

#include <string.h>

double prim(const Graph & g);
bool done(bool * const array, const unsigned int size);